import boto3
import os

#s3 = boto3.client('s3')
#s3.create_bucket(Bucket='vl.flask-app',
#                 CreateBucketConfiguration={'LocationConstraint': 'us-east-2'})
#s3.upload_file('./Dockerfile', 'vl.flask-app', 'Dockerfile')
#s3.upload_file('./MLP.pt', 'vl.flask-app', 'MLP.pt')
#s3.upload_file('./model.py', 'vl.flask-app', 'model.py')
#s3.upload_file('./webapp.py', 'vl.flask-app', 'webapp.py')

ebs = boto3.client('elasticbeanstalk')


response = ebs.create_application_version(
            ApplicationName='flask-predict',
            VersionLabel='v1',
            SourceBundle={'S3Bucket': 'vl.flask-app',
                            'S3Key': '.'},
            Process=True)